import 'package:demo/homePage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
class LogIn extends StatefulWidget {
  const LogIn({Key? key}) : super(key: key);

  @override
  _LogInState createState() => _LogInState();
}

class _LogInState extends State<LogIn> {
  final emailOrUNameController = TextEditingController();
  final passWordController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Column(
          children: <Widget>[
            Flexible(
                child: FractionallySizedBox(
                  alignment: Alignment.center,
                  heightFactor: 1.0,
                  widthFactor: 1.0,
                  child: Container(
                    color: Colors.white70,
                    child: LayoutBuilder(builder: (context, constraints) {
                      return Column(
                        children: <Widget>[
                          Container(
                            height: constraints.maxHeight * 0.05,
                            width: constraints.maxWidth,
                            // color: Colors.cyanAccent,
                          ),
                          Container(
                            height: constraints.maxHeight * 0.20,
                            width: constraints.maxWidth,
                            decoration: new BoxDecoration(
                                image: new DecorationImage(
                                  // fit: BoxFit.fill,
                                    image: AssetImage(
                                        'assets/images/signUp.png'))),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 10.0),
                            child: Container(
                              height: constraints.maxHeight * 0.1,
                              width: constraints.maxWidth,
                              // color: Colors.cyanAccent,
                              child: Center(
                                child: Text("LogIn",
                                    style:
                                    TextStyle(color: Colors.black54, fontSize: 40)
                                ),
                              )
                              ,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 0.0),
                            child: Container(
                              height: constraints.maxHeight * 0.05,
                              width: constraints.maxWidth,
                              // color: Colors.cyanAccent,
                              child: Center(
                                child: Text("Please Enter LogIn Details",
                                    style:
                                    TextStyle(color: Colors.black54, fontSize: 18)
                                ),
                              )
                              ,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 30.0,bottom: 20.0),
                            child: Container(
                              // color: Colors.greenAccent,
                              height: constraints.maxHeight * 0.1,
                              width: constraints.maxWidth * 0.8,
                              child: TextField(
                                controller: emailOrUNameController,
                                decoration: InputDecoration(
                                    hintText: "Email/UserName",
                                    border: OutlineInputBorder()),
                              ),
                            ),
                          ),
                          Container(
                            // color: Colors.greenAccent,
                            height: constraints.maxHeight * 0.1,
                            width: constraints.maxWidth * 0.8,
                            child: TextField(
                              controller: passWordController,
                              decoration: InputDecoration(
                                  hintText: "PassWord",
                                  border: OutlineInputBorder()),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 40.0),
                            child: ButtonTheme(
                              minWidth: 200.0,
                              height: 50,
                              child: RaisedButton(
                                onPressed: () async {
                                  SharedPreferences preference = await SharedPreferences.getInstance();
                                  var email = preference.getString('Email');
                                  var passWord = preference.getString('passWord');
                                  var userName = preference.getString('userName');
                                  if ((email == emailOrUNameController.text || userName == emailOrUNameController.text) && passWord == passWordController.text){
                                    Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
                                  }
                                },
                                child: Text('LogIn'),
                                color: Colors.greenAccent,
                                textColor: Colors.black54,
                                elevation: 6.0,
                                shape: RoundedRectangleBorder(
                                    borderRadius: new BorderRadius.circular(30)),
                              ),
                            ),
                          ),
                        ],
                      );
                    }),
                  ),
                ))
          ],
        )
    );
  }
}
