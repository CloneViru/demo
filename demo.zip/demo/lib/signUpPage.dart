import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:demo/logInPage.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({Key? key}) : super(key: key);

  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final firstNameController = TextEditingController();
  final lastNameController = TextEditingController();
  final userNameController = TextEditingController();
  final emailController = TextEditingController();
  final passWordController = TextEditingController();
  final repassWordController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: <Widget>[
          Flexible(
              child: FractionallySizedBox(
            alignment: Alignment.center,
                heightFactor: 1.0,
                widthFactor: 1.0,
                child: Container(
                  color: Colors.white70,
                  child: LayoutBuilder(builder: (context, constraints) {
                    return Column(
                      children: <Widget>[
                        Container(
                          height: constraints.maxHeight * 0.05,
                          width: constraints.maxWidth,
                          // color: Colors.cyanAccent,
                        ),
                        Container(
                          height: constraints.maxHeight * 0.12,
                          width: constraints.maxWidth,
                          decoration: new BoxDecoration(
                              image: new DecorationImage(
                                // fit: BoxFit.fill,
                                  image: AssetImage(
                                      'assets/images/signUp.png'))),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 10.0),
                          child: Container(
                            height: constraints.maxHeight * 0.07,
                            width: constraints.maxWidth,
                            // color: Colors.cyanAccent,
                            child: Center(
                              child: Text("Sign-Up",
                                style:
                                  TextStyle(color: Colors.black54, fontSize: 40)
                              ),
                            )
                            ,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 0.0),
                          child: Container(
                            height: constraints.maxHeight * 0.05,
                            width: constraints.maxWidth,
                            // color: Colors.cyanAccent,
                            child: Center(
                              child: Text("Please Enter Your Details",
                                  style:
                                  TextStyle(color: Colors.black54, fontSize: 18)
                              ),
                            )
                            ,
                          ),
                        ),
                        Container(
                          // color: Colors.greenAccent,
                          height: constraints.maxHeight * 0.1,
                          width: constraints.maxWidth * 0.8,
                          child: TextField(
                            controller: firstNameController,
                            decoration: InputDecoration(
                                hintText: "First Name",
                                border: OutlineInputBorder()),
                          ),
                        ),
                        Container(
                          // color: Colors.greenAccent,
                          height: constraints.maxHeight * 0.1,
                          width: constraints.maxWidth * 0.8,
                          child: TextField(
                            controller: lastNameController,
                            decoration: InputDecoration(
                                hintText: "Last Name",
                                border: OutlineInputBorder()),
                          ),
                        ),
                        Container(
                          // color: Colors.greenAccent,
                          height: constraints.maxHeight * 0.1,
                          width: constraints.maxWidth * 0.8,
                          child: TextField(
                            controller: userNameController,
                            decoration: InputDecoration(
                                hintText: "Username",
                                border: OutlineInputBorder()),
                          ),
                        ),
                        Container(
                          // color: Colors.greenAccent,
                          height: constraints.maxHeight * 0.1,
                          width: constraints.maxWidth * 0.8,
                          child: TextField(
                            controller: emailController,
                            decoration: InputDecoration(
                                hintText: "Email Address",
                                border: OutlineInputBorder()),
                          ),
                        ),
                        Container(
                          // color: Colors.greenAccent,
                          height: constraints.maxHeight * 0.1,
                          width: constraints.maxWidth * 0.8,
                          child: TextField(
                            controller: passWordController,
                            decoration: InputDecoration(
                                hintText: "Password",
                                border: OutlineInputBorder()),
                          ),
                        ),
                        Container(
                          // color: Colors.greenAccent,
                          height: constraints.maxHeight * 0.1,
                          width: constraints.maxWidth * 0.8,
                          child: TextField(
                            controller: repassWordController,
                            decoration: InputDecoration(
                                hintText: "Confirm Password",
                                border: OutlineInputBorder()),
                          ),
                        ),
                        ButtonTheme(
                          minWidth: 200.0,
                          height: 50,
                          child: RaisedButton(
                            onPressed: () async {
                              SharedPreferences preference = await SharedPreferences.getInstance();
                              preference.setString('userName', userNameController.text);
                              preference.setString('Email', emailController.text);
                              preference.setString('firstName', firstNameController.text);
                              preference.setString('lastName', lastNameController.text);
                              preference.setString('passWord', passWordController.text);
                              preference.setString('ConfirmPassWord', repassWordController.text);

                              if (passWordController.text == repassWordController.text){
                                Navigator.push(context, MaterialPageRoute(builder: (context) => LogIn()));
                              }else{
                                final snackBar = SnackBar(
                                  content: const Text('Please Enter Valid Details'),
                                  action: SnackBarAction(
                                    label: 'ok',
                                    onPressed: () {
                                      // Some code to undo the change.
                                    },
                                  ),
                                );
                                ScaffoldMessenger.of(context).showSnackBar(snackBar);
                              }
                            },
                            child: Text('Sign-Up'),
                            color: Colors.greenAccent,
                            textColor: Colors.black54,
                            elevation: 6.0,
                            shape: RoundedRectangleBorder(
                                borderRadius: new BorderRadius.circular(30)),
                          ),
                        ),
                      ],
                    );
                  }),
                ),
          ))
        ],
      )
    );
  }
}
