import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

String stringResponse = "";
class _HomePageState extends State<HomePage> {
  late Map map;
  late Map dataResponse;
  List listResponse = [];
  Future<bool> getUserData() async  {
    http.Response response;
    response = await http.get(Uri.parse("https://reqres.in/api/users?page=2"));
    if (response.statusCode == 200){
      setState(() {
        map = json.decode(response.body);
        listResponse = map['data'];
      });
      return true;
    }else{
      return false;
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('user data'),
      ),
      body: ListView.builder(itemBuilder: (context, index){
        return Container(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Image.network(listResponse[index]['avatar']),
              ),
              Text(listResponse[index]['id'].toString()),
              Text(listResponse[index]['email'].toString()),
              Text(listResponse[index]['first_name'].toString()),
              Text(listResponse[index]['last_name'].toString()),
            ],
          ),
        );
      },
      itemCount:listResponse.length,
      ),
    );
  }
}
