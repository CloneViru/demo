import 'package:demo/signUpPage.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: SignUpPage(),
      debugShowCheckedModeBanner: false,
  ));
}
